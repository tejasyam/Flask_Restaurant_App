from app import application
from flask import jsonify, Response, session, url_for, app
from app.models import *
from app import *
import uuid
import datetime
from marshmallow import Schema, fields
from flask_restful import Resource, Api
from flask_apispec.views import MethodResource
from flask_apispec import marshal_with, doc, use_kwargs
import json
class SignUpRequest(Schema):
    username=fields.Str(default='username')
    password=fields.Str(default='password')
    name=fields.Str(default='name')
    level=fields.Int(default=0)

class LoginRequest(Schema):
    username=fields.Str(default='username')
    password=fields.Str(default='password')

class AddVendorRequest(Schema):
    user_id=fields.Str(default='user_id')
class AddItemRequest(Schema):
    item_name=fields.Str(default='item_name')
    calories_per_gm=fields.Int(default=100)
    available_quantity = fields.Int(default=100)
    restaurant_name= fields.Str(default='abc hotel')
    unit_price= fields.Int(default=0)

class VendorsListResponse(Schema):
    vendors=fields.List(fields.Dict())

class ItemListResponse(Schema):
    items=fields.List(fields.Dict())

class APIResponse(Schema):
    message=fields.Str(default='Success')

class ItemsOrderList(Schema):
    items=fields.List(fields.Dict())

class PlaceOrderRequest(Schema):
    order_id= fields.Str(default='order_id')

class ListOrderResponse(Schema):
    orders=fields.List(fields.Dict())

#  Restful way of creating APIs through Flask Restful

class SignUpAPI(MethodResource, Resource):

    @doc(description="Sign Up API", tags=['SignUP API'])
    @use_kwargs(SignUpRequest, location=('json'))
    @marshal_with((APIResponse))

    def post(self,**kwargs):
        try:
            user=User(
                uuid.uuid4(),
                kwargs['name'],
                kwargs['password'],
                kwargs['level'])

            db.session.add(user)
            db.session.commit()
            return APIResponse().dump(dict(message='User is successfully registered')),200
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to register User : {str(e)}')),400

api.add_resource(SignUpAPI, '/signup')
docs.register(SignUpAPI)

class LoginAPI(MethodResource, Resource):
    @doc(description='Login API',tags=['Login API'])
    @use_kwargs(LoginRequest, location=('json') )
    @marshal_with(APIResponse) #marshalling
    def post(self,**kwargs):
        try:
            user=User.query.filter_by(username=kwargs['username'],password=kwargs['password'])
            if user:
                print('logged in')
                session['user_id']=user.user_id
                print(f'User_id : {str(session["user_id"])}')
                return APIResponse().dump(dict(message='User is successfully logged in'))
            else:
                return APIResponse().dump(dict(message="User not found")),404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to find login User : {str(e)}'))

api.add_resource(LoginAPI, '/login')
docs.register(LoginAPI)

class LogoutAPI(MethodResource, Resource):
    @doc(description='Logout API',tags=['Logout API'])
    @marshal_with(APIResponse) #marshalling
    def post(self,**kwargs):
        try:
            if session['user_id']:
                session['user_id']=None
                return APIResponse().dump(dict(message="User is successfully logged out"))
            else :
                return APIResponse().dump(dict(message="User is not logged in ")),401
        except Exception as e:
            return APIResponse().dump(dict(message=f'Not able to logout User : {str(e)}'))

api.add_resource(LogoutAPI, '/logout')
docs.register(LogoutAPI)
class AddVendorAPI(MethodResource, Resource):
    @doc(description='Add Vendor API', tags=['Vendor API'])
    @use_kwargs(AddVendorRequest,location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self,**kwargs):
        try:
            if session['user_id']:
                user_id=session['user_id']
                user_type=User.query.filter_by(user_id=user_id).first().level
                print(user_id)
                if user_type==2:
                    vendor_user_id=kwargs['user_id']
                    print(vendor_user_id)
                    user=User.query.filter_by(user_id=vendor_user_id).first()
                    print(user.level)
                    user.level=1
                    #db.session.add(user)
                    db.session.commit()
                    return APIResponse().dump(dict(message="Vendor is successfully added")),200
                else:
                    return APIResponse().dump(dict(message="Logged User is not Admin")),405
            else:
                return APIResponse().dump(dict(message='User is not logged in')),401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to add vendor : {str(e)}')),400


api.add_resource(AddVendorAPI, '/add_vendor')
docs.register(AddVendorAPI)


class GetVendorsAPI(MethodResource, Resource):
    @doc(description='Get All Vendors API', tags=['Vendor API'])
    #@marshal_with(VendorsListResponse) @marshalling
    def get(self):
        try:
            if session['user_id']:
                user_id=session['user_id']
                user_type=User.query.filter_by(user_id=user_id).first().level
                print(user_id)
                if user_type == 2:
                    vendors = User.query.filter_by(level=1)
                    vendors_list=list()
                    for vendor in vendors:
                        vendors_dict=dict()
                        vendors_dict['vendor_id']=vendor.user_id
                        vendors_dict['name']=vendor.name
                        vendors_list.append(vendors_dict)
                    return VendorsListResponse().dump(dict(vendors=vendors_list )),200
                else:
                    return APIResponse().dump(dict(message='Logged User is not an Admin'))
            else:
                return APIResponse().dump(dict(message='User is not logged in')),401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to list vendors : {str(e)}'))
api.add_resource(GetVendorsAPI, '/list_vendors')
docs.register(GetVendorsAPI)

class AddItemAPI(MethodResource, Resource):
    @doc(description='Add Item API',tags=['Items API'])
    @use_kwargs(AddItemRequest,location=('json'))
    @marshal_with(APIResponse) #marshalling
    def post(self,**kwargs):
        try:
            if session['user_id']:
                user_id=session['user_id']
                user_type=User.query.filter_by(user_id=user_id).first().level
                print(user_id)
                if user_type==1:
                    item=Item(
                        uuid.uuid4(),
                        session['user_id'],
                        kwargs['item_name'],
                        kwargs['calories_per_gm'],
                        kwargs['available_quantity'],
                        kwargs['restaurant_name'],
                        kwargs['unit_price']
                    )
                    db.session.add(item)
                    db.session.commit()
                    return APIResponse().dump(dict(message='Item is successfully added'))
                else:
                    return APIResponse().dump(dict(message='Logged in user is not a Vendor'))
            else:
                return APIResponse().dump(dict(message='Vendor is not logged in')), 401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to get list of vendors : {str(e)}'))


api.add_resource(AddItemAPI, '/add_item')
docs.register(AddItemAPI)


class ListItemsAPI(MethodResource, Resource):
    @doc(description='List All Items API',tags=['Items API'])
    # @marshall_with(ItemListResponse) #marshallin
    def get(self):
        try:
            if session['user_id']:
                items=Item.query.all()
                items_list=list()
                for item in items:
                    item_dict=dict()
                    item_dict['item_id']=item.item_id
                    item_dict['item_name']=item.item_name
                    item_dict ['calories_per_gm']=item.calories_per_gm
                    item_dict['available_quantity']=item.available_quantity
                    item_dict['unit_price']=item.unit_price
                    items_list.append(item_dict)

                return ItemListResponse().dump(dict(items=items_list)),200
            else:
                return APIResponse().dump(dict(message='User is not logged in')),401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to list items : {str(e)}'))
api.add_resource(ListItemsAPI, '/list_items')
docs.register(ListItemsAPI)


class CreateItemOrderAPI(MethodResource, Resource):
    @doc(description='Create Items Order API', tags=['Order API'])
    @use_kwargs(ItemsOrderList, location=('json'))
    @marshal_with(APIResponse)  # @marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                print(user_id)
                if user_type == 0:
                    order_id = uuid.uuid4()
                    order = Order(order_id, user_id)
                    db.session.add(order)

                    for item in kwargs['items']:
                        item = dict(item)
                        order_item = OrderItems(
                            uuid.uuid4(),
                            order_id,
                            item['item_id'],
                            item['quantity']
                        )
                        db.session.add(order_item)
                    db.session.commit()
                    return APIResponse().dump(dict(message=f'Items for the Order are successfull'))
                else:
                    return APIResponse().dump(dict(message='LoggedIn User is not a Customer'))
            else:
                return APIResponse().dump(dict(message='Customer is not logged in')), 401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to add items for ordering : {str(e)}'))


api.add_resource(CreateItemOrderAPI, '/create_items_order')
docs.register(CreateItemOrderAPI)


class PlaceOrderAPI(MethodResource, Resource):
    pass


api.add_resource(PlaceOrderAPI, '/place_order')
docs.register(PlaceOrderAPI)


class ListOrdersByCustomerAPI(MethodResource, Resource):
    pass


api.add_resource(ListOrdersByCustomerAPI, '/list_orders')
docs.register(ListOrdersByCustomerAPI)


class ListAllOrdersAPI(MethodResource, Resource):
    pass


api.add_resource(ListAllOrdersAPI, '/list_all_orders')
docs.register(ListAllOrdersAPI)